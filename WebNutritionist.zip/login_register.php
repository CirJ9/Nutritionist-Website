<?php

session_start();
require_once 'config.php'; 

if (isset($_POST['register'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password']; 
    $role = 'user';

    $errors = [];
    if (empty($name)) { $errors[] = 'Name is required.'; }
    if (strlen($name) < 2) { $errors[] = 'Name must be at least 2 characters.'; }
    if (empty($email)) { $errors[] = 'Email is required.'; }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $errors[] = 'Invalid email format.'; }
    if (empty($password)) { $errors[] = 'Password is required.'; }
    if (strlen($password)) <  { $errors[] = 'Password must be at least 8 characters long.'; }

    if (!empty($errors)) {
        $_SESSION['register_error'] = implode('<br>', $errors);
        $_SESSION['active_form'] = 'register';
        header("Location: users_Account.php");
        exit();
    }

    $stmt_check = $conn->prepare("SELECT email FROM users_data WHERE email = :email");
    $stmt_check->bindParam(':email', $email);
    $stmt_check->execute();

    if ($stmt_check->rowCount() > 0) { 
        $_SESSION['register_error'] = 'Email is already registered!';
        $_SESSION['active_form'] = 'register';
    } else {
        $password_hashed = password_hash($password, PASSWORD_DEFAULT);

        $stmt_insert = $conn->prepare("INSERT INTO users_data (name, email, password, role) VALUES (:name, :email, :password, :role)");
        $stmt_insert->bindParam(':name', $name);
        $stmt_insert->bindParam(':email', $email);
        $stmt_insert->bindParam(':password', $password_hashed);
        $stmt_insert->bindParam(':role', $role);
        $stmt_insert->execute();
    }

    header("Location: users_Account.php");
    exit();
}

if(isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $errors = [];
    if (empty($email)) { $errors[] = 'Email is required.'; }
    if (empty($password)) { $errors[] = 'Password is required.'; }

    if (!empty($errors)) {
        $_SESSION['login_error'] = implode('<br>', $errors);
        $_SESSION['active_form'] = 'login';
        header("Location: users_Account.php");
        exit();
    }

    $stmt_login = $conn->prepare("SELECT * FROM users_data WHERE email = :email");
    $stmt_login->bindParam(':email', $email);
    $stmt_login->execute();
    $users = $stmt_login->fetch(PDO::FETCH_ASSOC); 

    if ($users && password_verify($password, $users['password'])) {
        $_SESSION['name'] = $users['name'];
        $_SESSION['email'] = $users['email'];

        if($users['role'] === 'admin') {
            header("Location: admin_dashboard.php");
        } else {
            header("Location: home.php");
        }
        exit();
    } else {
        $_SESSION['login_error'] = 'Incorrect email or password';
        $_SESSION['active_form'] = 'login';
        header("Location: users_Account.php");
        exit();
    }
}

?>