<?php

$host = getenv('DB_HOST') ?: "localhost"; 
$user = getenv('DB_USER') ?: "root";     
$password = getenv('DB_PASSWORD') ?: ""; 
$database = getenv('DB_DATABASE') ?: "webnutri_db"; 

try {
    $conn = new PDO("mysql:host=$host;dbname=$database;charset=utf8mb4", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection Failed: " . $e->getMessage());
}

?>