<?php
session_start();
include 'connectDB.php';

$userIDToDelete = $_GET['deletebyid'] ?? null;
$loggedInUserID = $_SESSION['user_id'] ?? null;

if (!$userIDToDelete) {
    header('location: manage_users.php');
    exit;
}

if ($userIDToDelete == $loggedInUserID) {
    echo '<script>alert("You cannot delete the account you are currently logged in with!"); window.location.href = "manage_users.php";</script>';
    exit;
}

try {
    $sql_delete = "DELETE FROM users WHERE user_id = ?";
    $delete_statement = $conn->prepare($sql_delete);
    $delete_result = $delete_statement->execute([$userIDToDelete]);

    if ($delete_result) {
        header('location: manage_users.php');
        exit;
    } else {
        echo '<script>alert("Delete Failed."); window.location.href = "manage_users.php";</script>';
        exit;
    }
} catch (PDOException $e) {
    echo '<script>alert("Database error: ' . $e->getMessage() . '"); window.location.href = "manage_users.php";</script>';
    exit;
}
?>