<?php
session_start();
include 'connectDB.php';

$username = $_SESSION['username'] ?? 'Admin';

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['registerStudent'])) {
    $student_number = trim($_POST['student_number']);
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name']);
    $last_name = trim($_POST['last_name']);
    $grade_level = trim($_POST['grade_level']);
    $course = trim($_POST['course']); 

    try {
        $stmt_check_student = $conn->prepare("SELECT student_id FROM students WHERE student_number = ?");
        $stmt_check_student->execute([$student_number]);
        $existing_student = $stmt_check_student->fetch(PDO::FETCH_ASSOC);

        if ($existing_student) {
            $message = "Student with this Student Number already exists!";
            $message_type = "warning";
            $inserted_student_id = $existing_student['student_id'];
        } else {
            $sql_insert_student = "INSERT INTO students (student_number, `Last Name`, `First Name`, `Middle Name`, grade_level, Course) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt_insert_student = $conn->prepare($sql_insert_student);
            $stmt_insert_student->execute([$student_number, $last_name, $first_name, $middle_name, $grade_level, $course]);
            $inserted_student_id = $conn->lastInsertId();
            $message = "Student registered successfully!";
            $message_type = "success";
        }

        if ($inserted_student_id) {
            $current_date = date('Y-m-d H:i:s');
            $status = 'Present';

            $stmt_check_attendance = $conn->prepare("SELECT attendance_id FROM attendance WHERE student_id = ? AND DATE(date) = ?");
            $stmt_check_attendance->execute([$inserted_student_id, date('Y-m-d')]);
            $existing_attendance = $stmt_check_attendance->fetch(PDO::FETCH_ASSOC);

            if ($existing_attendance) {
                $message .= " Attendance for today already recorded for this student.";
                $message_type = "info";
            } else {
                $sql_insert_attendance = "INSERT INTO attendance (student_id, date, status) VALUES (?, ?, ?)";
                $stmt_insert_attendance = $conn->prepare($sql_insert_attendance);
                $stmt_insert_attendance->execute([$inserted_student_id, $current_date, $status]);
                $message .= " Attendance marked as 'Present' for today.";
                $message_type = ($message_type == "warning") ? "warning" : "success";
            }
        }
    } catch (PDOException $e) {
        $message = "Database error: " . $e->getMessage();
        $message_type = "danger";
    }
}

$grade_levels = ['First Year', 'Second Year', 'Third Year', 'Fourth Year'];
$courses = ['bscs', 'bsit', 'bsee', 'bse', 'bshm', 'bsf'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Student Registration & Attendance</title>
  <link rel="icon" href="./img/cvsu-logo.png" />
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
  <style>
    body {
      background-color: #f3fef3;
      font-family: Georgia, serif;
    }

    nav {
      background-color: #14532d;
      padding: 15px 20px;
    }
    nav .navbar-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    nav a.nav-brand {
      text-decoration: none;
      color: white;
      font-weight: bold;
      font-size: 20px;
      display: flex;
      align-items: center;
    }
    .img-logo {
      width: 40px;
      height: 40px;
      margin-right: 10px;
    }
    .gold-line {
      height: 5px;
      background-color: #ffd700;
    }

    .user-info {
      display: flex;
      align-items: center;
    }
    .user-info .dropdown-toggle {
      color: white;
      font-weight: bold;
      background: none;
      border: none;
    }
    .profile-pic {
      width: 35px;
      height: 35px;
      object-fit: cover;
      border-radius: 50%;
      margin-left: 10px;
    }

    .dashboard-links {
      text-align: center;
      margin: 20px 0;
    }
    .dashboard-links a {
      margin: 0 10px;
      text-decoration: none;
      color: #14532d;
      font-weight: bold;
    }
    .dashboard-links a:hover {
      color: #d4af37;
    }

    .form-container {
        max-width: 600px;
        margin: 50px auto;
        padding: 30px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
  </style>
</head>
<body>

<nav>
  <div class="navbar-content">
    <a href="admin_home.php" class="nav-brand">
      <img src="./img/cvsu-logo.png" class="img-logo" alt="CVSU Logo" />
      ATTENDANCE LOGGER
    </a>
    <div class="dropdown user-info">
      <button class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
        <?= htmlspecialchars($username) ?>
        <img src="img/profile_pic.png" alt="Profile Picture" class="profile-pic">
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item text-danger fw-bold" href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="gold-line"></div>

<div class="container mt-4 text-center">
  <h1 class="text-success">Student Registration & Attendance</h1>
</div>

<div class="dashboard-links">
  <a href="admin_home.php">Dashboard</a>
  <a href="view_attendance.php">View Attendance</a>
  <a href="manage_users.php">Manage Users</a>
  <a href="student_attendancesheet.php">Student Input</a>
</div>

<div class="container main-content mt-4">
    <div class="form-container">
        <?php if ($message): ?>
            <div class="alert alert-<?= $message_type ?> alert-dismissible fade show" role="alert">
                <?= $message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <h3 class="mb-4 text-center text-primary">Student Registration</h3>
        <form action="" method="post">
            <div class="mb-3">
                <label for="student_number" class="form-label">Student Number:</label>
                <input type="text" class="form-control" id="student_number" name="student_number" required>
            </div>
            <div class="row mb-3">
                <div class="col">
                    <label for="last_name" class="form-label">Last Name:</label>
                    <input type="text" class="form-control" id="last_name" name="last_name" required>
                </div>
                <div class="col">
                    <label for="first_name" class="form-label">First Name:</label>
                    <input type="text" class="form-control" id="first_name" name="first_name" required>
                </div>
                <div class="col">
                    <label for="middle_name" class="form-label">Middle Name:</label>
                    <input type="text" class="form-control" id="middle_name" name="middle_name">
                </div>
            </div>
            <div class="mb-3">
                <label for="grade_level" class="form-label">Grade Level:</label>
                <select class="form-select" id="grade_level" name="grade_level" required>
                    <option value="">Select Grade Level</option>
                    <?php foreach ($grade_levels as $level): ?>
                        <option value="<?= htmlspecialchars($level) ?>"><?= htmlspecialchars($level) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="course" class="form-label">Course:</label>
                <select class="form-select" id="course" name="course" required>
                    <option value="">Select Course</option>
                    <?php foreach ($courses as $c): ?>
                        <option value="<?= htmlspecialchars($c) ?>"><?= htmlspecialchars($c) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="d-grid mt-4">
                <button type="submit" name="registerStudent" class="btn btn-success">Register Student & Mark Present</button>
            </div>
        </form>
    </div>
</div>

<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>