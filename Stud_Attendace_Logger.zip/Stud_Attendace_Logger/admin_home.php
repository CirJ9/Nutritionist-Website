<?php
session_start();
include 'connectDB.php';

$username = $_SESSION['username'] ?? 'Admin';
$today = date('Y-m-d');

$present_count = 0;
$absent_count = 0;
$late_count = 0;

try {
    $stmt_present = $conn->prepare("SELECT COUNT(*) FROM attendance WHERE DATE(date) = ? AND status = 'Present'");
    $stmt_present->execute([$today]);
    $present_count = $stmt_present->fetchColumn();

    $stmt_absent = $conn->prepare("SELECT COUNT(*) FROM attendance WHERE DATE(date) = ? AND status = 'Absent'");
    $stmt_absent->execute([$today]);
    $absent_count = $stmt_absent->fetchColumn();

    $stmt_late = $conn->prepare("SELECT COUNT(*) FROM attendance WHERE DATE(date) = ? AND status = 'Late'");
    $stmt_late->execute([$today]);
    $late_count = $stmt_late->fetchColumn();

} catch (PDOException $e) {
   }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Dashboard</title>
  <link rel="icon" href="./img/cvsu-logo.png" />
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
  <style>
    body {
      background-color: #f3fef3;
      font-family: Georgia, serif;
    }

    nav {
      background-color: #14532d;
      padding: 15px 20px;
    }
    nav .navbar-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    nav a.nav-brand {
      text-decoration: none;
      color: white;
      font-weight: bold;
      font-size: 20px;
      display: flex;
      align-items: center;
    }
    .img-logo {
      width: 40px;
      height: 40px;
      margin-right: 10px;
    }
    .gold-line {
      height: 5px;
      background-color: #ffd700;
    }

    .user-info {
      display: flex;
      align-items: center;
    }
    .user-info .dropdown-toggle {
      color: white;
      font-weight: bold;
      background: none;
      border: none;
    }
    .profile-pic {
      width: 35px;
      height: 35px;
      object-fit: cover;
      border-radius: 50%;
      margin-left: 10px;
    }

    .dashboard-links {
      text-align: center;
      margin: 20px 0;
    }
    .dashboard-links a {
      margin: 0 10px;
      text-decoration: none;
      color: #14532d;
      font-weight: bold;
    }
    .dashboard-links a:hover {
      color: #d4af37;
    }

    .dashboard-section {
      display: flex;
      justify-content: center;
      gap: 20px;
      margin: 50px auto;
      max-width: 1000px;
      flex-wrap: wrap;
    }
    .dashboard-box {
      background-color: white;
      border: 2px solid #ccc;
      border-radius: 10px;
      padding: 50px 30px;
      text-align: center;
      flex: 1 1 30%;
      min-width: 250px;
      transition: transform 0.2s;
    }
    .dashboard-box:hover {
      transform: scale(1.03);
      border-color: #ffd700;
    }
    .dashboard-box.green-border {
        border-color: #198754;
    }
    .dashboard-box.red-border {
        border-color: #dc3545;
    }
    .dashboard-box.yellow-border {
        border-color: #ffc107;
    }
    .dashboard-box h3 {
        font-size: 1.5rem;
        margin-bottom: 10px;
    }
    .dashboard-box .count {
        font-size: 3rem;
        font-weight: bold;
    }
  </style>
</head>
<body>

<nav>
  <div class="navbar-content">
    <a href="admin_home.php" class="nav-brand">
      <img src="./img/cvsu-logo.png" class="img-logo" alt="CVSU Logo" />ATTENDANCE LOGGER</a>
    <div class="dropdown user-info">
      <button class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
        <?= htmlspecialchars($username) ?>
        <img src="img/profile_pic.png" alt="Profile Picture" class="profile-pic">
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item text-danger fw-bold" href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="gold-line"></div>

<div class="container mt-4 text-center">
  <h1 class="text-success">Admin Dashboard</h1>
</div>

<div class="dashboard-links">
  <a href="admin_home.php">Dashboard</a>
  <a href="view_attendance.php">View Attendance</a>
  <a href="manage_users.php">Manage Users</a>
  <a href="student_attendancesheet.php">Student Input</a>
</div>

<div class="dashboard-section">
  <div class="dashboard-box green-border">
    <h3 class="text-success">Present Students Today</h3>
    <div class="count text-success"><?= $present_count ?></div>
  </div>
  <div class="dashboard-box red-border">
    <h3 class="text-danger">Absent Students Today</h3>
    <div class="count text-danger"><?= $absent_count ?></div>
  </div>
  <div class="dashboard-box yellow-border">
    <h3 class="text-warning">Late Students Today</h3>
    <div class="count text-warning"><?= $late_count ?></div>
  </div>
</div>

<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>