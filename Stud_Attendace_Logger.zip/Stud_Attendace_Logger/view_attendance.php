<?php
session_start();
include 'connectDB.php';

$username = $_SESSION['username'] ?? 'Admin';
$search_student_name = $_GET['search_student'] ?? '';
$filter_status = $_GET['status_filter'] ?? '';
$filter_date = $_GET['date_filter'] ?? '';

$sql = "SELECT
            a.attendance_id,
            s.student_number,
            s.`Last Name` AS student_last_name,
            s.`First Name` AS student_first_name,
            s.`Middle Name` AS student_middle_name,
            s.grade_level,
            s.Course, 
            a.date,
            a.status
        FROM
            attendance a
        JOIN
            students s ON a.student_id = s.student_id
        WHERE 1=1";

$params = [];

if (!empty($search_student_name)) {
    $sql .= " AND (s.`First Name` LIKE :search_student_name OR s.`Middle Name` LIKE :search_student_name OR s.`Last Name` LIKE :search_student_name)";
    $params[':search_student_name'] = "%$search_student_name%";
}
if (!empty($filter_status)) {
    $sql .= " AND a.status = :status_filter";
    $params[':status_filter'] = $filter_status;
}
if (!empty($filter_date)) {
    $sql .= " AND DATE(a.date) = :date_filter";
    $params[':date_filter'] = $filter_date;
}

$sql .= " ORDER BY a.date DESC, s.`Last Name` ASC, s.`First Name` ASC"; 
$stmt = $conn->prepare($sql);
$stmt->execute($params);
$attendance_records = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>View Attendance Records</title>
  <link rel="icon" href="./img/cvsu-logo.png" />
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
  <style>
    body {
      background-color: #f3fef3;
      font-family: Georgia, serif;
    }

    nav {
      background-color: #14532d;
      padding: 15px 20px;
    }
    nav .navbar-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    nav a.nav-brand {
      text-decoration: none;
      color: white;
      font-weight: bold;
      font-size: 20px;
      display: flex;
      align-items: center;
    }
    .img-logo {
      width: 40px;
      height: 40px;
      margin-right: 10px;
    }
    .gold-line {
      height: 5px;
      background-color: #ffd700;
    }

    .user-info {
      display: flex;
      align-items: center;
    }
    .user-info .dropdown-toggle {
      color: white;
      font-weight: bold;
      background: none;
      border: none;
    }
    .profile-pic {
      width: 35px;
      height: 35px;
      object-fit: cover;
      border-radius: 50%;
      margin-left: 10px;
    }

    .dashboard-links {
      text-align: center;
      margin: 20px 0;
    }
    .dashboard-links a {
      margin: 0 10px;
      text-decoration: none;
      color: #14532d;
      font-weight: bold;
    }
    .dashboard-links a:hover {
      color: #d4af37;
    }

    .table-container {
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        margin-top: 20px;
    }
  </style>
</head>
<body>

<nav>
  <div class="navbar-content">
    <a href="admin_home.php" class="nav-brand">
      <img src="./img/cvsu-logo.png" class="img-logo" alt="CVSU Logo" />
      ATTENDANCE LOGGER
    </a>
    <div class="dropdown user-info">
      <button class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
        <?= htmlspecialchars($username) ?>
        <img src="img/profile_pic.png" alt="Profile Picture" class="profile-pic">
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item text-danger fw-bold" href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="gold-line"></div>

<div class="container mt-4 text-center">
  <h1 class="text-success">View Attendance Records</h1>
</div>

<div class="dashboard-links">
  <a href="admin_home.php">Dashboard</a>
  <a href="view_attendance.php">View Attendance</a>
  <a href="manage_users.php">Manage Users</a>
  <a href="student_attendancesheet.php">Student Input</a>
</div>

<div class="container main-content mt-4">
    <form method="GET" class="row g-2 mb-4 align-items-end">
        <div class="col-md-4">
            <label for="search_student" class="form-label">Student Name:</label>
            <input type="text" name="search_student" id="search_student" class="form-control" placeholder="Search by student name" value="<?= htmlspecialchars($search_student_name) ?>">
        </div>
        <div class="col-md-3">
            <label for="status_filter" class="form-label">Status:</label>
            <select name="status_filter" id="status_filter" class="form-select">
                <option value="">All</option>
                <option value="Present" <?= $filter_status === 'Present' ? 'selected' : '' ?>>Present</option>
                <option value="Absent" <?= $filter_status === 'Absent' ? 'selected' : '' ?>>Absent</option>
                <option value="Late" <?= $filter_status === 'Late' ? 'selected' : '' ?>>Late</option>
            </select>
        </div>
        <div class="col-md-3">
            <label for="date_filter" class="form-label">Date:</label>
            <input type="date" class="form-control" id="date_filter" name="date_filter" value="<?= htmlspecialchars($filter_date) ?>">
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-success w-100">Filter</button>
        </div>
        <div class="col-md-2 mt-2">
            <a href="view_attendance.php" class="btn btn-secondary w-100">Reset</a>
        </div>
    </form>


    <div class="table-container">
        <div class="d-flex justify-content-end mb-3">
          <a href="insert_attendance.php" class="btn btn-primary">Add Attendance Manually</a>          
        </div>
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead class="table-success">
                    <tr>
                        <th>ID</th>
                        <th>Student No.</th>
                        <th>Student Name</th>
                        <th>Grade Level</th>
                        <th>Course</th> <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($attendance_records): ?>
                        <?php foreach ($attendance_records as $record): ?>
                            <tr>
                                <td><?= htmlspecialchars($record['attendance_id']) ?></td>
                                <td><?= htmlspecialchars($record['student_number']) ?></td>
                                <td><?= htmlspecialchars($record['student_last_name'] . ', ' . $record['student_first_name'] . ' ' . $record['student_middle_name']) ?></td>
                                <td><?= htmlspecialchars($record['grade_level']) ?></td>
                                <td><?= htmlspecialchars($record['Course']) ?></td> <td><?= htmlspecialchars(date('Y-m-d', strtotime($record['date']))) ?></td>
                                <td>
                                    <?php
                                        $status_color_class = '';
                                        switch ($record['status']) {
                                            case 'Present': $status_color_class = 'text-success'; break;
                                            case 'Absent': $status_color_class = 'text-danger'; break;
                                            case 'Late': $status_color_class = 'text-warning'; break;
                                        }
                                    ?>
                                    <span class="fw-bold <?= $status_color_class ?>"><?= htmlspecialchars($record['status']) ?></span>
                                </td>
                                <td>
                                    <a href="update_attendance.php?updatebyid=<?= $record['attendance_id'] ?>" class="btn btn-sm btn-primary me-2">Edit</a>
                                    <a href="delete_attendance.php?deletebyid=<?= $record['attendance_id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this attendance record?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center">No attendance records found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>