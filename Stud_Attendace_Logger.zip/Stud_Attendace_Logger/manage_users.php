<?php
session_start();
include 'connectDB.php';

$username_session = $_SESSION['username'] ?? 'Guest';
$user_role = $_SESSION['role'] ?? '';

if ($user_role !== 'admin') {
    header("Location: landing_page.php");
    exit();
}

$search = $_GET['search'] ?? '';
$roleFilter = $_GET['role'] ?? '';

$sql = "SELECT user_id, username, full_name, role FROM users WHERE 1=1";
$params = [];

if (!empty($search)) {
    $sql .= " AND (username LIKE :search OR full_name LIKE :search)";
    $params[':search'] = "%$search%";
}
if (!empty($roleFilter)) {
    $sql .= " AND role = :role";
    $params[':role'] = $roleFilter;
}

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Manage Users</title>
    <link rel="icon" href="./img/cvsu-logo.png" />
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
    <style>
        body {
            background-color: #f3fef3;
            font-family: Georgia, serif;
        }
        nav {
            background-color: #14532d;
            padding: 15px 20px;
        }
        nav .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        nav a.nav-brand {
            text-decoration: none;
            color: white;
            font-weight: bold;
            font-size: 20px;
            display: flex;
            align-items: center;
        }
        .img-logo {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .gold-line {
            height: 5px;
            background-color: #ffd700;
        }
        .user-info {
            display: flex;
            align-items: center;
        }
        .user-info .dropdown-toggle {
            color: white;
            font-weight: bold;
            background: none;
            border: none;
        }
        .profile-pic {
            width: 35px;
            height: 35px;
            object-fit: cover;
            border-radius: 50%;
            margin-left: 10px;
        }
        .dashboard-links {
            text-align: center;
            margin: 20px 0;
        }
        .dashboard-links a {
            margin: 0 10px;
            text-decoration: none;
            color: #14532d;
            font-weight: bold;
        }
        .dashboard-links a:hover {
            color: #d4af37;
        }
        .table-container {
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
    </style>
</head>
<body>

<nav>
    <div class="navbar-content">
        <a href="admin_home.php" class="nav-brand">
            <img src="./img/cvsu-logo.png" class="img-logo" alt="CVSU Logo" />
            ATTENDANCE LOGGER
        </a>
        <div class="dropdown user-info">
            <button class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                <?= htmlspecialchars($username_session) ?>
                <img src="img/profile_pic.png" alt="Profile Picture" class="profile-pic" />
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item text-danger fw-bold" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="gold-line"></div>

<div class="container mt-4 text-center">
    <h1 class="text-success">Manage Users</h1>
</div>

<div class="dashboard-links">
    <a href="admin_home.php">Dashboard</a>
    <a href="view_attendance.php">View Attendance</a>
    <a href="manage_users.php">Manage Users</a>
    <a href="student_attendancesheet.php">Student Input</a>
</div>

<div class="container main-content mt-4">
    <div class="d-flex justify-content-end mb-3">
        <a href="insert_user.php" class="btn btn-success">Add New User +</a>
    </div>

    <form method="GET" class="row g-2 mb-4">
        <div class="col-md-4">
            <input type="text" name="search" class="form-control" placeholder="Search by name or username"
                   value="<?= htmlspecialchars($search) ?>">
        </div>
        <div class="col-md-3">
            <select name="role" class="form-select">
                <option value="">All Roles</option>
                <option value="admin" <?= $roleFilter === 'admin' ? 'selected' : '' ?>>Admin</option>
                <option value="teacher" <?= $roleFilter === 'teacher' ? 'selected' : '' ?>>Teacher</option>
            </select>
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-success w-100">Filter</button>
        </div>
        <div class="col-md-2">
            <a href="manage_users.php" class="btn btn-secondary w-100">Reset</a>
        </div>
    </form>

    <div class="table-container">
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead class="table-success">
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Full Name</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($users): ?>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?= $user['user_id'] ?></td>
                                <td><?= htmlspecialchars($user['username']) ?></td>
                                <td><?= htmlspecialchars($user['full_name']) ?></td>
                                <td><?= htmlspecialchars($user['role']) ?></td>
                                <td>
                                    <a href="update_user.php?updatebyid=<?= $user['user_id'] ?>" class="btn btn-sm btn-primary me-2">Edit</a>
                                    <a href="delete_user.php?deletebyid=<?= $user['user_id'] ?>" class="btn btn-sm btn-danger"
                                       onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center">No users found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>