<?php
include 'connectDB.php';

$userID = $_GET['updatebyid'] ?? null;

if (!$userID) {
    header('location: manage_users.php');
    exit();
}

$original_username = '';
$original_fullName = '';
$original_role = '';

$sql = "SELECT username, full_name, role FROM users WHERE user_id = ?";
$statement = $conn->prepare($sql);
$statement->execute([$userID]);
$result = $statement->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $original_username = htmlspecialchars($result['username']);
    $original_fullName = htmlspecialchars($result['full_name']);
    $original_role = htmlspecialchars($result['role']);
} else {
    header('location: manage_users.php');
    exit();
}

if (isset($_POST['updateButton'])) {
    $newUsername = $_POST['username'];
    $newFullName = $_POST['full_name'];
    $newRole = $_POST['role'];
    $newPassword = $_POST['password'];

    $sql_update = "UPDATE users SET username = ?, full_name = ?, role = ? WHERE user_id = ?";
    $params = [$newUsername, $newFullName, $newRole, $userID];

    if (!empty($newPassword)) {
        $hashed_password = password_hash($newPassword, PASSWORD_DEFAULT);
        $sql_update = "UPDATE users SET username = ?, password = ?, full_name = ?, role = ? WHERE user_id = ?";
        array_splice($params, 1, 0, $hashed_password);
    }

    $update_statement = $conn->prepare($sql_update);
    $update_result = $update_statement->execute($params);

    if ($update_result) {
        header('location: manage_users.php');
        exit();
    } else {
        echo '<script> alert("Update Failed."); window.location.href = "manage_users.php"; </script>';
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User Record</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
    <style>
        body {
            background-color: #f3fef3;
            font-family: Georgia, serif;
            padding: 20px;
        }

        .form-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="form-container">
            <h1 class="mb-4 text-center text-success">UPDATE USER INFO</h1>
            <form action="" method="POST">
                <input type="hidden" name="ID" value="<?= $userID ?>">
                <div class="mb-3">
                    <label for="username" class="form-label">Username:</label>
                    <input type="text" class="form-control" id="username" name="username" value="<?= $original_username ?>" autocomplete="off" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">New Password (leave blank to keep current):</label>
                    <input type="password" class="form-control" id="password" name="password" autocomplete="new-password">
                    <small class="text-muted">Enter a new password only if you want to change it.</small>
                </div>
                <div class="mb-3">
                    <label for="full_name" class="form-label">Full Name:</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" value="<?= $original_fullName ?>" autocomplete="off" required>
                </div>
                <div class="mb-3">
                    <label for="role" class="form-label">Role:</label>
                    <select class="form-select" id="role" name="role" required>
                        <option value="admin" <?= ($original_role == 'admin') ? 'selected' : ''; ?>>Admin</option>
                        <option value="teacher" <?= ($original_role == 'teacher') ? 'selected' : ''; ?>>Teacher</option>
                    </select>
                </div>

                <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                    <button type="submit" name="updateButton" class="btn btn-success me-md-2">Update</button>
                    <a href="manage_users.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>