<?php
session_start();
require_once 'connectDB.php'; 

if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    try {
        $stmt_login = $conn->prepare("SELECT user_id, username, password, role FROM users WHERE username = ?");
        $stmt_login->execute([$username]);
        $user = $stmt_login->fetch(PDO::FETCH_ASSOC); 

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id']; 
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role']; 

            if ($user['role'] === 'admin') {
                header("Location: admin_home.php");
            } elseif ($user['role'] === 'teacher') {
                header("Location: teacher_home.php");
            } else {
                header("Location: landing_page.php"); 
            }
            exit();
        } else {
            $_SESSION['login_error'] = 'Invalid username or password.';
            $_SESSION['active_form'] = 'login';
            header("Location: landing_page.php");
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['login_error'] = 'Login failed: ' . $e->getMessage();
        $_SESSION['active_form'] = 'login';
        header("Location: landing_page.php");
        exit();
    }
}

header("Location: landing_page.php");
exit();
