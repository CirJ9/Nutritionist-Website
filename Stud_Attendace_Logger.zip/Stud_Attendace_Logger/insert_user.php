<?php
session_start();
include 'connectDB.php';

$username_session = $_SESSION['username'] ?? 'Admin';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['insertButton'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $fullName = $_POST['full_name'];
    $role = $_POST['role'];

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (username, password, full_name, role) VALUES (?, ?, ?, ?)";
    $insertStatement = $conn->prepare($sql);
    
    $result = $insertStatement->execute([$username, $hashed_password, $fullName, $role]);

    if ($result) {
        header('Location: manage_users.php');
        exit();
    } else {
        echo "<script> alert('Failed To Insert User.'); </script>";
        header('Location: manage_users.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Add New User</title>
    <link rel="icon" href="./img/cvsu-logo.png" />
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
    <style>
        body {
            background-color: #f3fef3;
            font-family: Georgia, serif;
        }
        nav {
            background-color: #14532d;
            padding: 15px 20px;
        }
        nav .navbar-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        nav a.nav-brand {
            text-decoration: none;
            color: white;
            font-weight: bold;
            font-size: 20px;
            display: flex;
            align-items: center;
        }
        .img-logo {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .gold-line {
            height: 5px;
            background-color: #ffd700;
        }
        .user-info {
            display: flex;
            align-items: center;
        }
        .user-info .dropdown-toggle {
            color: white;
            font-weight: bold;
            background: none;
            border: none;
        }
        .profile-pic {
            width: 35px;
            height: 35px;
            object-fit: cover;
            border-radius: 50%;
            margin-left: 10px;
        }
        .dashboard-links {
            text-align: center;
            margin: 20px 0;
        }
        .dashboard-links a {
            margin: 0 10px;
            text-decoration: none;
            color: #14532d;
            font-weight: bold;
        }
        .dashboard-links a:hover {
            color: #d4af37;
        }
        .form-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>

<nav>
    <div class="navbar-content">
        <a href="admin_home.php" class="nav-brand">
            <img src="./img/cvsu-logo.png" class="img-logo" alt="CVSU Logo" />
            ATTENDANCE LOGGER
        </a>
        <div class="dropdown user-info">
            <button class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                <?= htmlspecialchars($username_session) ?>
                <img src="img/profile_pic.png" alt="Profile Picture" class="profile-pic" />
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item text-danger fw-bold" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="gold-line"></div>

<div class="container mt-4 text-center">
    <h1 class="text-success">Add New User</h1>
</div>

<div class="dashboard-links">
    <a href="admin_home.php">Dashboard</a>
    <a href="view_attendance.php">View Attendance</a>
    <a href="manage_users.php">Manage Users</a>
    <a href="student_attendancesheet.php">Student Input</a>
</div>

<div class="container">
    <div class="form-container">
        <h1 class="mb-4 text-center text-success">ADD NEW USER</h1>
        <form action="" method="post">
            <div class="mb-3">
                <label for="username" class="form-label">Username:</label>
                <input type="text" class="form-control" id="username" name="username" autocomplete="off" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password:</label>
                <input type="password" class="form-control" id="password" name="password" autocomplete="new-password" required>
            </div>
            <div class="mb-3">
                <label for="full_name" class="form-label">Full Name:</label>
                <input type="text" class="form-control" id="full_name" name="full_name" autocomplete="off" required>
            </div>
            <div class="mb-3">
                <label for="role" class="form-label">Role:</label>
                <select class="form-select" id="role" name="role" required>
                    <option value="">Select Role</option>
                    <option value="admin">Admin</option>
                    <option value="teacher">Teacher</option>
                </select>
            </div>

            <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                <button type="submit" name="insertButton" class="btn btn-success me-md-2">Add User</button>
                <a href="manage_users.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>