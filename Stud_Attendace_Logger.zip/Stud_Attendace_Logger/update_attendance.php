<?php
session_start();
include 'connectDB.php';

$username = $_SESSION['username'] ?? 'Admin';
$message = '';
$message_type = '';

$attendance_id_to_update = $_GET['updatebyid'] ?? null;
$current_record = null;

if ($attendance_id_to_update) {
    try {
        $stmt_fetch = $conn->prepare("SELECT a.attendance_id, a.student_id, s.`Last Name`, s.`First Name`, s.`Middle Name`, s.student_number, a.date, a.status FROM attendance a JOIN students s ON a.student_id = s.student_id WHERE a.attendance_id = ?");
        $stmt_fetch->execute([$attendance_id_to_update]);
        $current_record = $stmt_fetch->fetch(PDO::FETCH_ASSOC);

        if (!$current_record) {
            $message = "Attendance record not found.";
            $message_type = "danger";
            $attendance_id_to_update = null;
        }
    } catch (PDOException $e) {
        $message = "Database error fetching record: " . $e->getMessage();
        $message_type = "danger";
        $attendance_id_to_update = null;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['updateAttendance'])) {
    $attendance_id = $_POST['attendance_id'];
    $student_id = $_POST['student_id'];
    $date = $_POST['date'];
    $status = $_POST['status'];

    try {
        $sql_update = "UPDATE attendance SET student_id = ?, date = ?, status = ? WHERE attendance_id = ?";
        $stmt = $conn->prepare($sql_update);
        $update_result = $stmt->execute([$student_id, $date, $status, $attendance_id]);

        if ($update_result) {
            $message = "Attendance record updated successfully!";
            $message_type = "success";
            $stmt_fetch = $conn->prepare("SELECT a.attendance_id, a.student_id, s.`Last Name`, s.`First Name`, s.`Middle Name`, s.student_number, a.date, a.status FROM attendance a JOIN students s ON a.student_id = s.student_id WHERE a.attendance_id = ?");
            $stmt_fetch->execute([$attendance_id]);
            $current_record = $stmt_fetch->fetch(PDO::FETCH_ASSOC);
        } else {
            $message = "Failed to update attendance record.";
            $message_type = "danger";
        }
    } catch (PDOException $e) {
        $message = "Database error updating record: " . $e->getMessage();
        $message_type = "danger";
    }
}

$students = [];
try {
    $stmt_students = $conn->query("SELECT student_id, `Last Name`, `First Name`, `Middle Name`, student_number FROM students ORDER BY `Last Name`, `First Name`");
    $students = $stmt_students->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = "Error fetching student data: " . $e->getMessage();
    $message_type = "danger";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Update Attendance</title>
  <link rel="icon" href="./img/cvsu-logo.png" />
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
  <style>
    body {
      background-color: #f3fef3;
      font-family: Georgia, serif;
    }

    nav {
      background-color: #14532d;
      padding: 15px 20px;
    }
    nav .navbar-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    nav a.nav-brand {
      text-decoration: none;
      color: white;
      font-weight: bold;
      font-size: 20px;
      display: flex;
      align-items: center;
    }
    .img-logo {
      width: 40px;
      height: 40px;
      margin-right: 10px;
    }
    .gold-line {
      height: 5px;
      background-color: #ffd700;
    }

    .user-info {
      display: flex;
      align-items: center;
    }
    .user-info .dropdown-toggle {
      color: white;
      font-weight: bold;
      background: none;
      border: none;
    }
    .profile-pic {
      width: 35px;
      height: 35px;
      object-fit: cover;
      border-radius: 50%;
      margin-left: 10px;
    }

    .dashboard-links {
      text-align: center;
      margin: 20px 0;
    }
    .dashboard-links a {
      margin: 0 10px;
      text-decoration: none;
      color: #14532d;
      font-weight: bold;
    }
    .dashboard-links a:hover {
      color: #d4af37;
    }

    .form-container {
        max-width: 600px;
        margin: 50px auto;
        padding: 30px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
  </style>
</head>
<body>

<nav>
  <div class="navbar-content">
    <a href="admin_home.php" class="nav-brand">
      <img src="./img/cvsu-logo.png" class="img-logo" alt="CVSU Logo" />
      ATTENDANCE LOGGER
    </a>
    <div class="dropdown user-info">
      <button class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
        <?= htmlspecialchars($username) ?>
        <img src="img/profile_pic.png" alt="Profile Picture" class="profile-pic">
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item text-danger fw-bold" href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="gold-line"></div>

<div class="container mt-4 text-center">
  <h1 class="text-success">Update Attendance Record</h1>
</div>

<div class="dashboard-links">
  <a href="admin_home.php">Dashboard</a>
  <a href="view_attendance.php">View Attendance</a>
  <a href="manage_users.php">Manage Users</a>
  <a href="student_attendancesheet.php">Student Input</a>
</div>

<div class="container main-content mt-4">
    <div class="form-container">
        <?php if ($message): ?>
            <div class="alert alert-<?= $message_type ?> alert-dismissible fade show" role="alert">
                <?= $message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <h3 class="mb-4 text-center text-primary">Update Attendance</h3>
        <?php if ($current_record): ?>
        <form action="" method="post">
            <input type="hidden" name="attendance_id" value="<?= htmlspecialchars($current_record['attendance_id']) ?>">
            <div class="mb-3">
                <label for="student_id" class="form-label">Student:</label>
                <select class="form-select" id="student_id" name="student_id" required>
                    <option value="">Select Student</option>
                    <?php foreach ($students as $student): ?>
                        <option value="<?= htmlspecialchars($student['student_id']) ?>"
                            <?= $student['student_id'] == $current_record['student_id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($student['Last Name'] . ', ' . $student['First Name'] . ' ' . $student['Middle Name']) ?> (<?= htmlspecialchars($student['student_number']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="date" class="form-label">Date:</label>
                <input type="date" class="form-control" id="date" name="date" value="<?= htmlspecialchars(date('Y-m-d', strtotime($current_record['date']))) ?>" required>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status:</label>
                <select class="form-select" id="status" name="status" required>
                    <option value="Present" <?= $current_record['status'] == 'Present' ? 'selected' : '' ?>>Present</option>
                    <option value="Absent" <?= $current_record['status'] == 'Absent' ? 'selected' : '' ?>>Absent</option>
                    <option value="Late" <?= $current_record['status'] == 'Late' ? 'selected' : '' ?>>Late</option>
                </select>
            </div>
            
            <div class="d-grid mt-4">
                <button type="submit" name="updateAttendance" class="btn btn-success">Update Attendance</button>
            </div>
        </form>
        <?php else: ?>
            <p class="text-center text-muted">Please select an attendance record to update from the <a href="view_attendance.php">View Attendance</a> page.</p>
        <?php endif; ?>
    </div>
</div>

<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>