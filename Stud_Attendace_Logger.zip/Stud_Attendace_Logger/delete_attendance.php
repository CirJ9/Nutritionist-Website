<?php
session_start();
include 'connectDB.php';

$attendance_id_to_delete = $_GET['deletebyid'] ?? null;

if (!$attendance_id_to_delete) {
    header('location: view_attendance.php');
    exit;
}

try {
    $sql_delete = "DELETE FROM attendance WHERE attendance_id = ?";
    $delete_statement = $conn->prepare($sql_delete);
    $delete_result = $delete_statement->execute([$attendance_id_to_delete]);

    if ($delete_result) {
        header('location: view_attendance.php');
        exit;
    } else {
        echo '<script>alert("Delete Failed."); window.location.href = "view_attendance.php";</script>';
        exit;
    }
} catch (PDOException $e) {
    echo '<script>alert("Database error: ' . $e->getMessage() . '"); window.location.href = "view_attendance.php";</script>';
    exit;
}
?>