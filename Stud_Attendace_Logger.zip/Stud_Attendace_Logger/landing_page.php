<?php 
session_start();

$errors = [
    'login' => $_SESSION['login_error'] ?? '',
];
$activeForm = $_SESSION['active_form'] ?? 'login';
session_unset(); 

function showError($error) {
    return !empty($error) ? "<div class='alert alert-danger text-center'>$error</div>" : '';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Logger</title>
    <link rel="icon" href="./img/cvsu-logo.png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <style>
        body {
            font-family: Georgia, serif;
            background-color:rgb(4, 95, 4); 
        }
        .login-container {
            max-width: 400px;
            margin: 80px auto;
            padding: 30px;
            border-radius: 10px;
            background-color: #ffffff;
            box-shadow: 0 0 10px rgba(0,0,0,0.15);
        }
        .logo {
            width: 80px;
            display: block;
            margin: 0 auto 15px;
        }
        .main-title {
            color:rgb(255, 215, 0);
            font-weight: bold;
            text-align: center;
        }
        .sub-title {
            color: #198754;
            font-size: 1.5rem;
            text-align: center;
            margin-bottom: 20px;
        }
        .btn-custom {
            background-color: #198754;
            color: white;
        }
        .btn-custom:hover {
            background-color: #14532d;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="main-title mt-4">CVSU - Naic | Attendance Logger</h1>
        <div class="login-container">
            <img src="img/cvsu-logo.png" alt="CVSU Logo" class="logo">
            <h2 class="sub-title">Login</h2>
            <form action="login_conn.php" method="post">
                <?= showError($errors['login']) ?>
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" name="username" id="username" class="form-control" placeholder="Enter username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" name="password" id="password" class="form-control" placeholder="Enter password" required>
                </div>
                <button type="submit" name="login" class="btn btn-custom w-100">Login</button>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
