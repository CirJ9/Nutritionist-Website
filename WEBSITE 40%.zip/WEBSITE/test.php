<?php
// Enable error reporting for development
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Spoonacular setup
$apiKey = "569cb694137d4b718ed7ba1864489117"; // Replace with your actual key

if (isset($_POST['food']) && isset($_POST['servings'])) {
    $foodName = urlencode($_POST['food']);
    $servings = floatval($_POST['servings']);

    $url = "https://api.spoonacular.com/recipes/guessNutrition?title=$foodName&apiKey=$apiKey";
    $response = file_get_contents($url);
    $data = json_decode($response, true);

    if (isset($data['calories'])) {
        $calories = $data['calories']['value'] * $servings;
        $fat = $data['fat']['value'] * $servings;
        $carbs = $data['carbs']['value'] * $servings;
    } else {
        $error = "No nutrition data found.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Nutrition Checker</title>
</head>
<body>
    <h2>Nutrition Checker (with Serving Size)</h2>

    <form method="POST">
        <label>Enter food name:</label><br>
        <input type="text" name="food" required><br><br>

        <label>Number of servings:</label><br>
        <input type="number" name="servings" min="0.1" step="0.1" value="1" required><br><br>

        <button type="submit">Check Nutrition</button>
    </form>

    <?php if (isset($calories)): ?>
        <h3>Results for "<?php echo htmlspecialchars($_POST['food']); ?>"</h3>
        <p>Servings: <?php echo htmlspecialchars($_POST['servings']); ?></p>
        <ul>
            <li>Calories: <?php echo round($calories, 2); ?> kcal</li>
            <li>Fat: <?php echo round($fat, 2); ?> g</li>
            <li>Carbs: <?php echo round($carbs, 2); ?> g</li>
        </ul>
    <?php elseif (isset($error)): ?>
        <p style="color:red;"><?php echo $error; ?></p>
    <?php endif; ?>
</body>
</html>
