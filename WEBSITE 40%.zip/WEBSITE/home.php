<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nutritionist</title>
  <link rel="stylesheet" href="page_home.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>

  <nav>
    <div class="logo">Nutritionist</div>
    <a href="PARTS.html">Home</a>
    <a href="Frameset.html">Meal plan</a>
    <a href="Wheelset.html">NutriCal</a>
    <a href="Fixiefork.html">Account</a>
    <a href="Fixiefork.html">About us</a>
    <div class="animation start-home"></div>
  </nav>

  <div class="container">
    <div class="card">
      <img src="images/go.webp" alt="HEX">
      <div class="intro">
        <h1>Go</h1>
        <p><span>"Go foods"</span> are part of a broader concept of categorizing foods by their nutritional benefits, with "Grow foods" providing the building blocks for the body and "Glow foods" supplying vitamins and minerals.</p>
      </div>
    </div>

    <div class="card">
      <img src="images/grow.jpg" alt="HEX">
      <div class="intro">
        <h1>Grow</h1>
        <p><span>"Grow foods"</span> foods rich in protein, calcium, and other essential nutrients that support physical growth and development, particularly in children and young adults.</p>
      </div>
    </div>

    <div class="card">
      <img src="images/glow.PNG" alt="HEX">
      <div class="intro">
        <h1>Glow</h1>
        <p><span>"Glow foods"</span> are a category of foods, primarily fruits and vegetables, that are rich in vitamins and minerals, particularly antioxidants like beta-carotene and vitamin C, known to support healthy skin, hair, and eyes.</p>
      </div>
    </div>
  </div>

</body>
</html>
