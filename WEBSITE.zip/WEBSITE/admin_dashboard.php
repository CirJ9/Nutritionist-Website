<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nutritionist Dashboard</title>
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/layout.css">
    <link rel="stylesheet" href="css/panel.css">
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">    
</head>
<body>

    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Nutritionist</h2>
            </div>
            <div class="user-info">
                <img src="path/to/default-avatar.png" alt="User Avatar" class="user-avatar">
                <p><strong><?php echo $_SESSION['name'] ?? 'User'; ?></strong></p>
                <small><?php echo $_SESSION['role'] ?? 'user'; ?></small>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="#" class="active"><i class="fas fa-chart-line"></i> Dashboard</a></li>
                    <li><a href="#"><i class="fas fa-list"></i> View Items</a></li>
                    <li>
                        <a href="#" class="dropdown-toggle" id="userManagementToggle"><i class="fas fa-users"></i> User Management</a>
                        </li>
                    <li><a href="#"><i class="fas fa-clipboard-check"></i> Manage Claims</a></li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
        </aside>

        <main class="main-content">
            <div class="header-bar">
                <h1>Dashboard Overview</h1>
            </div>

            <div class="card-grid">
                <div class="card card-blue">
                    <span class="card-number">2</span>
                    <p class="card-title">Total Members</p>
                </div>
                <div class="card card-dark-blue">
                    <span class="card-number">10</span>
                    <p class="card-title">Total Lost Items</p>
                </div>
                <div class="card card-green">
                    <span class="card-number">53</span>
                    <p class="card-title">Total Found Items</p>
                </div>
            </div>

            <div class="main-panel">
                <h2>Lost and Found System</h2>
                <p>This is where your dynamic dashboard content will be displayed.</p>
                </div>
        </main>
    </div>

    <script src="https://kit.fontawesome.com/your-font-awesome-kit-id.js" crossorigin="anonymous"></script>
    <script src="script.js"></script>

</body>
</html>