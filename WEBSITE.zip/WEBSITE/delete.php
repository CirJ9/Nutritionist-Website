<?php
session_start();
require_once 'config.php'; 
if (!isset($_SESSION['user_id'])) {
    header("Location: users_Account.php");
    exit();
}

$current_user_id = $_SESSION['user_id'];

if (isset($_GET["meal_num"])) {
    $meal_num = intval($_GET["meal_num"]); 

    try {
        $stmt = $conn->prepare("DELETE FROM `user_meals` WHERE meal_num = ? AND user_id = ?");
        $stmt->execute([$meal_num, $current_user_id]);

        if ($stmt->rowCount() > 0) { 
            header("Location: index.php?msg=Meal deleted successfully");
            exit();
        } else {
            header("Location: index.php?msg=Failed to delete meal: Record not found or you don't have permission.");
            exit();
        }
    } catch (PDOException $e) {
        header("Location: index.php?msg=Error deleting meal: " . $e->getMessage());
        exit();
    }
} else {
    header("Location: index.php?msg=No meal number provided to delete.");
    exit();
}
?>