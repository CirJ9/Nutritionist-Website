<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NutriHub</title>
        <link rel="stylesheet" href="css/home.css">
        <link rel="stylesheet" href="css/base.css">
        <link rel="stylesheet" href="css/layout.css">
        <link rel="stylesheet" href="css/panel.css">
        <link rel="icon" type="image/x-icon" href="images/favicon.ico">
   
</head>
<body>
  <nav class="navbar">
    <div class="logo"><a href="user_home.php">Nutritionist</a></div>
    <ul class="nav-links">
        <li><a href="track_meals.php">NutriTrack</a></li>
        <li><a href="about_Us.html">About</a></li>
        <li><a href="service.html">Services</a></li>
        <li>
            <div class="dropdown">
                <button class="profile-pic" type="button" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <img src="images\default_profile_pic.jpg" alt="Profile Picture">
                </button>
                <ul class="dropdown-menu" aria-labelledby="profileDropdown">
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </li>
      
    </ul>
  </nav>
    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" 
        integrity="sha384-kenU1KFdBIe4zVF0s0DzAza+Y1qVn4n1wX02b0f4wXw6l0iFw72+Qd6Bq2Xn2z" 
        crossorigin="anonymous"></script>   </body>
</html>