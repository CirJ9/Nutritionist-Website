<?php

session_start();
require_once 'config.php'; 

if (isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = 'user'; 

    try {
        $stmt_check_email = $conn->prepare("SELECT email FROM users_data WHERE email = ?");
        $stmt_check_email->execute([$email]);

        if ($stmt_check_email->rowCount() > 0) {
            $_SESSION['register_error'] = 'Email is already registered!';
            $_SESSION['active_form'] = 'register';
        } else {
            $stmt_insert_user = $conn->prepare("INSERT INTO users_data (name, email, password, role) VALUES (?, ?, ?, ?)");
            $stmt_insert_user->execute([$name, $email, $password, $role]);

            $_SESSION['register_success'] = 'Registration successful! Please login.';
            $_SESSION['active_form'] = 'login';
        }
    } catch (PDOException $e) {
        $_SESSION['register_error'] = 'Registration failed: ' . $e->getMessage();
        $_SESSION['active_form'] = 'register';
    }

    header("Location: users_Account.php");
    exit();
}

if(isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    try {
        $stmt_login = $conn->prepare("SELECT id, name, email, password, role FROM users_data WHERE email = ?");
        $stmt_login->execute([$email]);
        $users = $stmt_login->fetch(PDO::FETCH_ASSOC); 

        if ($users && password_verify($password, $users['password'])) {
            $_SESSION['user_id'] = $users['id']; 
            $_SESSION['name'] = $users['name'];
            $_SESSION['email'] = $users['email'];
            $_SESSION['role'] = $users['role']; 
            header("Location: user_home.php"); 
            exit();
        } else {
            $_SESSION['login_error'] = 'Invalid email or password.';
            $_SESSION['active_form'] = 'login';
        }
    } catch (PDOException $e) {
        $_SESSION['login_error'] = 'Login failed: ' . $e->getMessage();
        $_SESSION['active_form'] = 'login';
    }

    header("Location: users_Account.php");
    exit();
}
header("Location: users_Account.php");
exit();

?>